#include "mesh.h"

//CONSTRUCTOR
//arguments - dimensions of matrix
//allocates memory to matrix[x][y]
Mesh::Mesh(int n_x, int n_y):mn_dimX(n_x),
			     mn_dimY(n_y){
  matrix = new mesh*[mn_dimX];
  for (int i=0; i<mn_dimX; i++){
    matrix[i] = new mesh[mn_dimY];
  }
}

//DESTRUCTOR
//deallocates memory from the matrix
Mesh::~Mesh(){
  for (int i=0; i<mn_dimX; i++){
    delete[] matrix[i];
  }
  delete[] matrix;
}



//INPUT STREAM OVERLOAD
//allows user to enter values to the matrix
//e.g. "std::cin >> mymesh"
std::istream& operator>> (std::istream& os_in, const Mesh& mymesh){
  for (int i=0; i<mymesh.mn_dimX; i++){
    for (int j=0; j<mymesh.mn_dimY; j++){
      os_in >> mymesh.matrix[i][j].value;
    }
  }
}


//OUTPUT STREAM OVERLOAD
//prints matrix to screen
std::ostream& operator<< (std::ostream& os_out, const Mesh& mymesh){
  for (int i=0; i<mymesh.mn_dimX; i++){
    for (int j=0; j<mymesh.mn_dimY; j++){
      os_out << mymesh.matrix[i][j].value << " "; 
    }
    os_out << std::endl;
  }
}
