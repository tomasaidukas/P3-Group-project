#ifndef SHAPE_H
#define SHAPE_H
#include<iostream>
#include<math.h>
#include<stdlib.h>

typedef struct{
  int x;
  int y;
}point;



//SHAPE CLASS
class Shape{
protected:
  point *corners;
  int mn_numpoints;

public:
  Shape(int);//constructor
  double calcArea();
};


//CIRCLE
class Circle : public Shape{
 private:
  int mn_rad;
 
 public:
  Circle(int);//constructor
  double calcArea();
};


//TRIANGLE
class Triangle : public Shape{
 public:
  Triangle();//constructor
  double calcArea();
};

//RECTANGLE
class Rectangle : public Shape{
 public:
  Rectangle();//constructor
  double calcArea();
};

#endif
