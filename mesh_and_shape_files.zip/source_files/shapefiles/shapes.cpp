#include "shapes.h"



//SHAPE CONSTRUCTOR
Shape::Shape(int num): mn_numpoints(num){
    //allocate +memory
    corners = new point[mn_numpoints];
    
    //user inputs corners
    for (int i=0; i<mn_numpoints; i++){
      std::cin >> corners[i].x;
      std::cin >> corners[i].y;
    }
}



//CIRCLE CONSTRUCTOR
Circle::Circle(int n_rad):mn_rad(n_rad), Shape(1){}

//CIRCLE calcarea
double Circle::calcArea(){ return (M_PI*pow(mn_rad,2)); }


//TRIANGLE CONSTRUCTOR
Triangle::Triangle():Shape(3){}

//TRIANGLE calcarea
double Triangle::calcArea(){
  int xmax=corners[0].x, xmin=corners[0].x,
    ymax=corners[0].y, ymin=corners[0].y;

  for (int i=0; i<mn_numpoints; i++){
    if (i==0){ continue; }

    if (corners[i].x > corners[i-1].x){ xmax = corners[i].x;}
    if (corners[i].x < corners[i-1].x){ xmin = corners[i].x;}
    if (corners[i].y > corners[i-1].y){ ymax = corners[i].y;}
    if (corners[i].y < corners[i-1].x){ ymin = corners[i].y;}
  }

    return(0.5*(ymax-ymin)*(xmax-xmin));
}


//RECTANGLE CONSTRUCTOR
Rectangle::Rectangle():Shape(2){}

//RECTANGLE calcarea
double Rectangle::calcArea(){
  double length = corners[1].x - corners[0].x;
  double height = corners[1].y - corners[0].y;
  return (length*height);
}
