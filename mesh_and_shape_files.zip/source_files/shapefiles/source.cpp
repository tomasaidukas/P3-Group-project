#include "shapes.h"
#include<iostream>

int main(){
  Circle myshape(1.0);
  
  std::cout << myshape.calcArea() << std::endl;
  return 0;
}
